#we will design the user class

class User:
    def __init__(self, data):
        pass